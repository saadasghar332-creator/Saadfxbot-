# Architecture

## Current MVP

Android Flutter UI
    |
    | HTTP
    v
FastAPI backend
    |
    +-- signal_engine.py (placeholder)
    +-- risk.py
    +-- market endpoint (demo data)

## Production roadmap

1. Market-data adapter with a licensed provider.
2. Store OHLCV/spread data.
3. Feature pipeline shared by training and inference.
4. Walk-forward training and untouched final test set.
5. Probability calibration.
6. Paper-trading execution engine.
7. Persistent database.
8. Authentication + HTTPS.
9. Monitoring and kill switches.
10. Broker adapter, only after extensive paper testing.
