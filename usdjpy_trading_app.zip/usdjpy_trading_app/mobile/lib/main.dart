import 'dart:convert';
import 'package:flutter/material.dart';
import 'package:http/http.dart' as http;
import 'config.dart';

void main() {
  runApp(const TradingApp());
}

class TradingApp extends StatelessWidget {
  const TradingApp({super.key});

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: 'USD/JPY Trader',
      debugShowCheckedModeBanner: false,
      theme: ThemeData(
        colorScheme: ColorScheme.fromSeed(seedColor: Colors.blue),
        useMaterial3: true,
      ),
      home: const DashboardPage(),
    );
  }
}

class DashboardPage extends StatefulWidget {
  const DashboardPage({super.key});

  @override
  State<DashboardPage> createState() => _DashboardPageState();
}

class _DashboardPageState extends State<DashboardPage> {
  double? price;
  String signal = 'NO TRADE';
  double up = 0;
  double down = 0;
  String reason = 'Loading...';
  bool loading = false;

  Future<void> refresh() async {
    setState(() => loading = true);
    try {
      final market = await http.get(Uri.parse('$apiBaseUrl/api/market'));
      final sig = await http.get(Uri.parse('$apiBaseUrl/api/signal'));

      if (market.statusCode != 200 || sig.statusCode != 200) {
        throw Exception('API error');
      }

      final m = jsonDecode(market.body);
      final s = jsonDecode(sig.body);

      setState(() {
        price = (m['price'] as num).toDouble();
        signal = s['signal'];
        up = (s['up_probability'] as num).toDouble();
        down = (s['down_probability'] as num).toDouble();
        reason = s['reason'];
      });
    } catch (e) {
      setState(() {
        reason = 'Cannot reach backend. Check API address and network.';
      });
    } finally {
      setState(() => loading = false);
    }
  }

  @override
  void initState() {
    super.initState();
    refresh();
  }

  Color signalColor() {
    if (signal == 'UP') return Colors.green;
    if (signal == 'DOWN') return Colors.red;
    return Colors.orange;
  }

  @override
  Widget build(BuildContext context) {
    final c = signalColor();

    return Scaffold(
      appBar: AppBar(
        title: const Text('USD/JPY • 1 Minute'),
        actions: [
          IconButton(
            onPressed: loading ? null : refresh,
            icon: const Icon(Icons.refresh),
          ),
        ],
      ),
      body: RefreshIndicator(
        onRefresh: refresh,
        child: ListView(
          padding: const EdgeInsets.all(16),
          children: [
            Card(
              child: Padding(
                padding: const EdgeInsets.all(20),
                child: Column(
                  children: [
                    const Text('Current price'),
                    const SizedBox(height: 8),
                    Text(
                      price == null ? '--' : price!.toStringAsFixed(3),
                      style: Theme.of(context).textTheme.displaySmall,
                    ),
                  ],
                ),
              ),
            ),
            const SizedBox(height: 12),
            Card(
              child: Padding(
                padding: const EdgeInsets.all(20),
                child: Column(
                  children: [
                    Text(
                      signal,
                      style: TextStyle(
                        fontSize: 32,
                        fontWeight: FontWeight.bold,
                        color: c,
                      ),
                    ),
                    const SizedBox(height: 12),
                    LinearProgressIndicator(
                      value: up,
                      minHeight: 10,
                    ),
                    const SizedBox(height: 8),
                    Row(
                      mainAxisAlignment: MainAxisAlignment.spaceBetween,
                      children: [
                        Text('UP ${(up * 100).toStringAsFixed(1)}%'),
                        Text('DOWN ${(down * 100).toStringAsFixed(1)}%'),
                      ],
                    ),
                    const SizedBox(height: 12),
                    Text(reason, textAlign: TextAlign.center),
                  ],
                ),
              ),
            ),
            const SizedBox(height: 12),
            Card(
              child: Padding(
                padding: const EdgeInsets.all(16),
                child: Column(
                  children: const [
                    ListTile(
                      leading: Icon(Icons.shield),
                      title: Text('Paper trading only'),
                      subtitle: Text('No real orders are sent by this app.'),
                    ),
                    ListTile(
                      leading: Icon(Icons.warning_amber),
                      title: Text('Risk warning'),
                      subtitle: Text(
                        'Predictions are uncertain. Backtest and paper-trade before risking money.',
                      ),
                    ),
                  ],
                ),
              ),
            ),
            const SizedBox(height: 12),
            FilledButton.icon(
              onPressed: loading ? null : refresh,
              icon: const Icon(Icons.analytics),
              label: const Text('Refresh analysis'),
            ),
          ],
        ),
      ),
    );
  }
}
