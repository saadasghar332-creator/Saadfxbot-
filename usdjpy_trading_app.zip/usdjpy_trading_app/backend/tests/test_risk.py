from app.risk import calculate_position_size

def test_position_size():
    size = calculate_position_size(1000, 1, 5, 0.01)
    assert size == 200.0
