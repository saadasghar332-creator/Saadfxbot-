import random

def generate_signal():
    # Placeholder until a trained model is connected.
    # Deliberately conservative: most states return NO TRADE.
    up = round(random.uniform(0.35, 0.65), 4)
    down = round(1.0 - up, 4)

    if up >= 0.60:
        signal = "UP"
        reason = "Demo probability threshold met."
    elif down >= 0.60:
        signal = "DOWN"
        reason = "Demo probability threshold met."
    else:
        signal = "NO TRADE"
        reason = "Confidence below threshold."

    return {
        "signal": signal,
        "up_probability": up,
        "down_probability": down,
        "reason": reason,
    }
