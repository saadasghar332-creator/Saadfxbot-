from fastapi import FastAPI, HTTPException
from pydantic import BaseModel, Field
from typing import Literal
import math
import random

from .signal_engine import generate_signal
from .risk import calculate_position_size

app = FastAPI(
    title="USD/JPY Trading Research API",
    version="0.1.0",
    description="Paper-trading/analysis API. No broker orders."
)

class RiskRequest(BaseModel):
    account_balance: float = Field(gt=0)
    risk_percent: float = Field(gt=0, le=5)
    stop_pips: float = Field(gt=0)
    pip_value_per_unit: float = Field(default=0.01, gt=0)

class SignalResponse(BaseModel):
    symbol: str
    timeframe: str
    signal: Literal["UP", "DOWN", "NO TRADE"]
    up_probability: float
    down_probability: float
    reason: str
    paper_only: bool = True

@app.get("/health")
def health():
    return {"status": "ok", "paper_trading_only": True}

@app.get("/api/market")
def market():
    # Demo price only. Replace with a real/licensed market data adapter.
    price = round(156.0 + random.uniform(-0.25, 0.25), 3)
    return {
        "symbol": "USD/JPY",
        "timeframe": "1m",
        "price": price,
        "source": "DEMO",
        "paper_only": True
    }

@app.get("/api/signal", response_model=SignalResponse)
def signal():
    result = generate_signal()
    return {
        "symbol": "USD/JPY",
        "timeframe": "1m",
        **result,
        "paper_only": True
    }

@app.post("/api/risk")
def risk(req: RiskRequest):
    size = calculate_position_size(
        req.account_balance,
        req.risk_percent,
        req.stop_pips,
        req.pip_value_per_unit,
    )
    return {
        "position_size_units": size,
        "risk_amount": req.account_balance * req.risk_percent / 100,
        "paper_only": True
    }
