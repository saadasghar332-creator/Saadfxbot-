def calculate_position_size(
    account_balance: float,
    risk_percent: float,
    stop_pips: float,
    pip_value_per_unit: float,
) -> float:
    risk_amount = account_balance * risk_percent / 100
    size = risk_amount / (stop_pips * pip_value_per_unit)
    return round(size, 4)
